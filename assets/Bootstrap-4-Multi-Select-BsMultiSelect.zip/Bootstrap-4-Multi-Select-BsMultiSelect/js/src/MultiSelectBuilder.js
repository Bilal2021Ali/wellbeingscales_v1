import {composeSync} from './ToolsJs';
import {EventBinder, EventLoopFlag, containsAndSelf} from './ToolsDom'

export function MultiSelectBuilder (
    aspects
    ) 
{
    
}